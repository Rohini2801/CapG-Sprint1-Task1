﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task3_13April.Models;

namespace Task3_13April.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerdetController : ControllerBase
    {
        List<Customer> Clist = new List<Customer>()
        {
            new Customer() {cid=1,cname="Riya", caddr="Nagpur", contactno=8788975678, cmailid="riya@gmail.com"},
            new Customer() {cid=2,cname="Ana", caddr="Pune", contactno=9888975678, cmailid="ana@gmail.com"},
            new Customer() {cid=3,cname="Sana", caddr="Mumbai", contactno=9788975678, cmailid="sana@gmail.com"},
            new Customer() {cid=4,cname="John", caddr="Nagpur", contactno=7788975678, cmailid="john@gmail.com"},
            new Customer() {cid=5,cname="Will", caddr="Pune", contactno=7388975678, cmailid="will@gmail.com"},
            new Customer() {cid=6,cname="Smith", caddr="Umred", contactno=8188975678, cmailid="smith@gmail.com"}
        };

        public ActionResult<IEnumerable<Customer>> getallcust()
        {
            var result = from i in Clist select i;
            return result.ToList();
        }
    }
}
