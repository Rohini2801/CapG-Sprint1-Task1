﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Task3_13April.Models
{
    public class Customer
    {
        public int cid { get; set; }
        public string cname { get; set; }
        public string caddr { get; set; }
        public double contactno { get; set; }
        public string cmailid { get; set; }

    }
}
