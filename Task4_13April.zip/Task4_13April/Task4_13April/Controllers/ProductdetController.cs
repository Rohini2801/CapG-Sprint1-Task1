﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Task4_13April.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Task4_13April.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductdetController : ControllerBase
    {
        // GET: api/<ProductdetController>
        [HttpGet]
        public IEnumerable<ProductDet> Get()
        {

            DB1Context cnt = new DB1Context();
            return cnt.ProductDet;
        }

        // GET api/<ProductdetController>/5
        [HttpGet("{id}")]
        public IEnumerable<ProductDet> Get(int id)
        {
            DB1Context cnt = new DB1Context();
            var sql = from i in cnt.ProductDet where i.Pcode == id select i;
            return sql;
        }

        // POST api/<ProductdetController>
        [HttpPost]
        public void Post([FromBody] ProductDet value)
        {
            DB1Context cnt = new DB1Context();
            cnt.ProductDet.Add(value);
            cnt.SaveChanges();
        }

        // PUT api/<ProductdetController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] ProductDet value)
        {
            DB1Context cnt = new DB1Context();
            var det = cnt.ProductDet.Find(id);
            if (det != null)
            {
                det.Pname = value.Pname;
                det.Unitprice = value.Unitprice;
                det.Category = value.Category;
                det.Pdesc = value.Pdesc;
                det.Stockinhand = value.Stockinhand;
                cnt.SaveChanges();
            }
        }

        // DELETE api/<ProductdetController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            DB1Context cnt = new DB1Context();
            var obj = cnt.ProductDet.Find(id);
            cnt.ProductDet.Remove(obj);
            cnt.SaveChanges();
        }
    }
}
