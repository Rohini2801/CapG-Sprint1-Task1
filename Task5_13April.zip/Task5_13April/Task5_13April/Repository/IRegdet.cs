﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task5_13April.Models;

namespace Task5_13April.Repository
{
    public interface IRegdet
    {
        Task<IEnumerable<RegDet>> GetAllRegdet();

        Task<RegDet> GetRegdet(int rid);
        Task<RegDet> InsertRegdet(RegDet Robj);
        Task UpdateRegdet(RegDet Robj);
        Task DeleteRegdet(int rid);

    }
}
