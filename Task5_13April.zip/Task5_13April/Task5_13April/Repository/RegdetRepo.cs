﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task5_13April.Models;
using Microsoft.EntityFrameworkCore;

namespace Task5_13April.Repository
{
    public class RegdetRepo : IRegdet
    {
        private DB1Context _cnt;

        public RegdetRepo(DB1Context cnt)
        {
            _cnt = cnt;
        }
        public async Task DeleteRegdet(int rid)
        {
            var obj = await _cnt.RegDet.FindAsync(rid);
            _cnt.RegDet.Remove(obj);
            await _cnt.SaveChangesAsync();
        }

        public async Task<IEnumerable<RegDet>> GetAllRegdet()
        {
            return await _cnt.RegDet.Select(i => i).ToListAsync();
        }

        public async Task<RegDet> GetRegdet(int rid)
        {
            return await _cnt.RegDet.FindAsync(rid);
        }

        public async Task<RegDet> InsertRegdet(RegDet Robj)
        {
            _cnt.RegDet.Add(Robj);
            await _cnt.SaveChangesAsync();
            return Robj;
        }

        public async Task UpdateRegdet(RegDet Robj)
        {
            _cnt.Entry(Robj).State = EntityState.Modified;
            await _cnt.SaveChangesAsync();
        }
    }
}
