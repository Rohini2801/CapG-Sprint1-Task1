﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Task5_13April.Models
{
    public partial class DB1Context : DbContext
    {
        public DB1Context()
        {
        }

        public DB1Context(DbContextOptions<DB1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Category> Category { get; set; }
        public virtual DbSet<Dept> Dept { get; set; }
        public virtual DbSet<DeptEmpVw> DeptEmpVw { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Mark> Mark { get; set; }
        public virtual DbSet<Member> Member { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<ProductDet> ProductDet { get; set; }
        public virtual DbSet<RegDet> RegDet { get; set; }
        public virtual DbSet<Staffdet> Staffdet { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Swdv> Swdv { get; set; }
        public virtual DbSet<Swtst> Swtst { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-EIP2N8B\\SQLEXPRESS;Database=DB1;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("category");

                entity.HasIndex(e => e.Cid)
                    .HasName("UQ__category__D837D05E218E9596")
                    .IsUnique();

                entity.Property(e => e.Cdesc)
                    .HasColumnName("cdesc")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Dept>(entity =>
            {
                entity.HasKey(e => e.Did)
                    .HasName("PK__Dept__D877D216CB7A363E");

                entity.Property(e => e.Did)
                    .HasColumnName("did")
                    .ValueGeneratedNever();

                entity.Property(e => e.Dlocation)
                    .HasColumnName("dlocation")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Dname)
                    .HasColumnName("dname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<DeptEmpVw>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("deptEmpVw");

                entity.Property(e => e.Dname)
                    .HasColumnName("dname")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Eid)
                    .HasName("PK__employee__D9509F6DB63AF426");

                entity.ToTable("employee");

                entity.Property(e => e.Eid)
                    .HasColumnName("eid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Edesig)
                    .HasColumnName("edesig")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");

                entity.HasOne(d => d.D)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.Did)
                    .HasConstraintName("FK__employee__did__3D5E1FD2");
            });

            modelBuilder.Entity<Mark>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("mark");

                entity.Property(e => e.Marks).HasColumnName("marks");

                entity.Property(e => e.Strollno).HasColumnName("strollno");
            });

            modelBuilder.Entity<Member>(entity =>
            {
                entity.HasKey(e => e.Mid)
                    .HasName("PK__member__DF5032EC5CD18B3A");

                entity.ToTable("member");

                entity.Property(e => e.Mid).HasColumnName("mid");

                entity.Property(e => e.Mname)
                    .HasColumnName("mname")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__person__DD37D91A5BBBCAE7");

                entity.ToTable("person");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.PGender)
                    .HasColumnName("p_gender")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<ProductDet>(entity =>
            {
                entity.HasKey(e => e.Pcode)
                    .HasName("PK__ProductD__293812AAC4AF4D82");

                entity.Property(e => e.Pcode)
                    .HasColumnName("pcode")
                    .ValueGeneratedNever();

                entity.Property(e => e.Category)
                    .HasColumnName("category")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Pdesc)
                    .HasColumnName("pdesc")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Stockinhand).HasColumnName("stockinhand");

                entity.Property(e => e.Unitprice)
                    .HasColumnName("unitprice")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<RegDet>(entity =>
            {
                entity.HasKey(e => e.Rid)
                    .HasName("PK__RegDet__C2B7EDE859EAE937");

                entity.Property(e => e.Rid)
                    .HasColumnName("rid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Contactno).HasColumnName("contactno");

                entity.Property(e => e.Experience)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Firstname)
                    .HasColumnName("firstname")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Mailid)
                    .HasColumnName("mailid")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Skillset)
                    .HasColumnName("skillset")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Staffdet>(entity =>
            {
                entity.HasKey(e => e.Sid)
                    .HasName("PK__staffdet__DDDFDD361D26554C");

                entity.ToTable("staffdet");

                entity.Property(e => e.Sid)
                    .HasColumnName("sid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Scontactno).HasColumnName("scontactno");

                entity.Property(e => e.Smailid)
                    .HasColumnName("smailid")
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Sname)
                    .HasColumnName("sname")
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasKey(e => e.Strollno)
                    .HasName("PK__student__12EFEDA421D66C11");

                entity.ToTable("student");

                entity.Property(e => e.Strollno)
                    .HasColumnName("strollno")
                    .ValueGeneratedNever();

                entity.Property(e => e.Feeamount)
                    .HasColumnName("feeamount")
                    .HasColumnType("money");

                entity.Property(e => e.Stmailid)
                    .HasColumnName("stmailid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Stname)
                    .HasColumnName("stname")
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Swdv>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("SWDV");

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Edesig)
                    .HasColumnName("edesig")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Eid).HasColumnName("eid");

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<Swtst>(entity =>
            {
                entity.HasNoKey();

                entity.ToView("SWTST");

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Edesig)
                    .HasColumnName("edesig")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Eid).HasColumnName("eid");

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
