﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Task5_13April.Models
{
    public partial class RegDet
    {
        public int Rid { get; set; }
        public string Firstname { get; set; }
        public string Mailid { get; set; }
        public long Contactno { get; set; }
        public string Experience { get; set; }
        public string Skillset { get; set; }
    }
}
