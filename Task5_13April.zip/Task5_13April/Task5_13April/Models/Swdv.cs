﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Task5_13April.Models
{
    public partial class Swdv
    {
        public int Eid { get; set; }
        public string Ename { get; set; }
        public string Edesig { get; set; }
        public decimal? Esal { get; set; }
        public int? Did { get; set; }
    }
}
